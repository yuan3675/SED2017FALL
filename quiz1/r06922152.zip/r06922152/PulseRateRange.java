public class PulseRateRange extends SafeRange {
	private double upperBound;
	private double lowerBound;
	
	public PulseRateRange(double u, double l) {
		super(u, l);
	}
}