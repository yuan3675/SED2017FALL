public class TemperatureRange extends SafeRange {
	private double upperBound;
	private double lowerBound;
	
	public TemperatureRange(double u, double l){
		super(u, l);
	}
}